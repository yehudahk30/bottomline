package com.bottomline.autocomplete.controller;

import com.bottomline.autocomplete.model.AutocompleteTree;
import com.bottomline.autocomplete.util.AutocompleteConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AutocompleteController {

    @Autowired
    private CacheManager cacheManager;

    @GetMapping("/autocomplete/{word}")
    public ResponseEntity<List<String>> getAutoComplete(@PathVariable String word){
        AutocompleteTree tree = (AutocompleteTree) cacheManager.getCache(AutocompleteConstants.AUTO_COMP_CACHE)
                .get(AutocompleteConstants.NAMES_TREE_CACHE).get();
        List<String> suggestions = tree.getSuggestions(word);
        return new ResponseEntity<>(suggestions, HttpStatus.OK);
    }
}
