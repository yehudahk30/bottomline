package com.bottomline.autocomplete.persistence.jpa.repository;

import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NameRepository extends JpaRepository<NameEntity, Long> {

//    List<NameEntity> getAllNames();

    NameEntity save(NameEntity name);
}
