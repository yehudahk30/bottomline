package com.bottomline.autocomplete.util;

public class AutocompleteConstants {
    public static final String EMPTY = "";
    public static final String AUTO_COMP_CACHE = "AUTO_COMP_CACHE";
    public static final String NAMES_TREE_CACHE = "NAMES_TREE_CACHE";
}
