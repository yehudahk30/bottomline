package com.bottomline.autocomplete.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@Builder
@AllArgsConstructor
public class TreeNode {
    private Map<Character, TreeNode> children;
    String accumulatedChars;
    private boolean isWholeWord;

    public TreeNode(){
        super();
        children = new ConcurrentHashMap<>();
    }
}
