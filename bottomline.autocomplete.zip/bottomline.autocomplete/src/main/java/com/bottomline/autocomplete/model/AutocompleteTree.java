package com.bottomline.autocomplete.model;

import com.bottomline.autocomplete.util.AutocompleteConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.security.DenyAll;
import java.util.*;

@Data
@Builder
@AllArgsConstructor
public class AutocompleteTree {

    private TreeNode root;

    public AutocompleteTree(){
        super();
        root = new TreeNode();
        root.setAccumulatedChars(AutocompleteConstants.EMPTY);
    }

    public void addWord(String word){
        if(word == null || word.isEmpty()){
            return;
        }
        TreeNode currNode = root;
        String prefix = null;
        for (char letter: word.toCharArray()){
            prefix = currNode.getAccumulatedChars();
            currNode = currNode.getChildren().computeIfAbsent(letter,n -> new TreeNode());
            if(!foundNodeWithLetter(currNode)) {
                currNode.setAccumulatedChars(prefix.concat(String.valueOf(letter)));
            }
        }
        currNode.setWholeWord(true);
    }

    public List<String> getSuggestions(String word){
        TreeNode currNode = root;
        List<String> suggestions = new ArrayList<>();
        for(char letter: word.toCharArray()){
            if(currNode != null)
                currNode = currNode.getChildren().get(letter);
        }
        if(currNode!= null){
            getBranchSuggestions(suggestions, currNode);
        }
        return suggestions;
    }

    //this is a recursive method for finding DFS
    //the auto complete suggestions in each branch
    private void getBranchSuggestions(List<String> suggestions, TreeNode node){
        suggestions.add(node.getAccumulatedChars());
        Map<Character, TreeNode> children = node.getChildren();
        if(children != null && !children.isEmpty()){
            children.values().forEach(n -> getBranchSuggestions(suggestions, n));
        }
    }

    private boolean foundNodeWithLetter(TreeNode currNode) {
        if(currNode != null && currNode.getAccumulatedChars() != null){
            return true;
        }
        return false;
    }
}
