package com.bottomline.autocomplete.persistence.jpa.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name = "name")
@NoArgsConstructor
public class NameEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name =  "firstName")
    private String firstName;

    public NameEntity(String _firstName){
        this.firstName=_firstName;
    }

}
