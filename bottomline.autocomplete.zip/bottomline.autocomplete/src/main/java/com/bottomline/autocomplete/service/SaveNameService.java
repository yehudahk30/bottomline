package com.bottomline.autocomplete.service;

import com.bottomline.autocomplete.controller.NameController;
import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SaveNameService {

    @Autowired
    private NameController nameController;

    public void saveNames(List<NameEntity> names){
        nameController.saveNames(names);
    }
}
