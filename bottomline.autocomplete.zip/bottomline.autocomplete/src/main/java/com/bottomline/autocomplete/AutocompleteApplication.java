package com.bottomline.autocomplete;

import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import com.bottomline.autocomplete.service.LoadNamesService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.util.List;

@Slf4j
@SpringBootApplication
public class AutocompleteApplication implements CommandLineRunner {

	@Autowired
	private LoadNamesService loadNamesService;

	public AutocompleteApplication(LoadNamesService loadNamesService){};

	public static void main(String[] args) {

		SpringApplication.run(AutocompleteApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("AutocompleteApplication is running...");
	}
}
