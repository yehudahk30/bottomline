package com.bottomline.autocomplete.service;

import com.bottomline.autocomplete.controller.TreeController;
import com.bottomline.autocomplete.model.AutocompleteTree;
import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import com.bottomline.autocomplete.util.AutocompleteConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.CacheManager;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Component
public class InitApplication {

    @Autowired
    private LoadNamesService loadNamesService;

    @Autowired
    private TreeController treeController;

    @Autowired
    private CacheManager cacheManager;

    @EventListener(ApplicationReadyEvent.class)
    public void initApp() throws IOException {
        //load names from file to H2
        loadNamesService.loadNamesFromFile();

        //load names from H2
        List<NameEntity> names = loadNamesService.loadNamesFromDb();

        //build tree from names
        AutocompleteTree appTree = treeController.buildTreeFromNames(names);

        //put tree in cache
        cacheManager.getCache(AutocompleteConstants.AUTO_COMP_CACHE).put(AutocompleteConstants.NAMES_TREE_CACHE, appTree);
    }
}
