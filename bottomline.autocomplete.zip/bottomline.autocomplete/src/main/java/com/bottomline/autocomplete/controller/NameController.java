package com.bottomline.autocomplete.controller;

import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import com.bottomline.autocomplete.persistence.jpa.repository.NameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Controller
public class NameController {

    @Autowired
    private NameRepository nameRepository;

    public void saveNames(List<NameEntity> names){
        if(!CollectionUtils.isEmpty(names)){
            names.forEach(n -> nameRepository.save(n));
        }
    }

    public void saveName(NameEntity name){
        if(name != null){
            nameRepository.save(name);
        }
    }
}
