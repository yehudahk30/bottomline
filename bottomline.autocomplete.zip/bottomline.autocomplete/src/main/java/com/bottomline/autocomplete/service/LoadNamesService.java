package com.bottomline.autocomplete.service;

import com.bottomline.autocomplete.config.AutocompleteConfig;
import com.bottomline.autocomplete.controller.TreeController;
import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import com.bottomline.autocomplete.persistence.jpa.repository.NameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class LoadNamesService {

    @Autowired
    private AutocompleteConfig config;

    @Autowired
    private SaveNameService saveNameService;

    @Autowired
    private NameRepository nameRepository;

    @Autowired
    private TreeController treeController;

    public List<NameEntity> loadNamesFromDb() throws IOException {
        return nameRepository.findAll();
    }

    public void loadNamesFromFile() throws IOException {
        List<NameEntity> names = readNamesFromFile();
        saveNameService.saveNames(names);
    }

    private List<NameEntity> readNamesFromFile() throws IOException {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(config.getNamesFileName());
        InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
        BufferedReader reader = new BufferedReader(streamReader);
        List<NameEntity> names = new ArrayList<>();
        for (String line; ( line = reader.readLine()) != null;) {
            names.add(convertLineToEntity(line));
        }
        return names;
    }

    private NameEntity convertLineToEntity(String line){
        return new NameEntity(line);
    }
}
