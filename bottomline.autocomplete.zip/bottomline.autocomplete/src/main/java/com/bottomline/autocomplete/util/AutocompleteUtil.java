package com.bottomline.autocomplete.util;

import org.springframework.stereotype.Component;

@Component
public class AutocompleteUtil {


}
