package com.bottomline.autocomplete.controller;

import com.bottomline.autocomplete.model.AutocompleteTree;
import com.bottomline.autocomplete.model.TreeNode;
import com.bottomline.autocomplete.persistence.jpa.entity.NameEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Controller
public class TreeController {

    public AutocompleteTree buildTreeFromNames(List<NameEntity> names){
        if(CollectionUtils.isEmpty(names)){
            return null;
        }
        AutocompleteTree tree = new AutocompleteTree();
        for (NameEntity name: names) {
            tree.addWord(name.getFirstName());
        }
        tree.toString();
        return tree;
    }

}
